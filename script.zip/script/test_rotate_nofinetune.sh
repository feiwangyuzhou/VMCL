#!/bin/sh

gpu=0
kge='RotatE' # 'TransE', 'DistMult', 'ComplEx', or 'RotatE'


dim=32
num_train_subgraph=10000


dataset='nell' # 'fb237', 'WN18RR', or 'nell'
version=1 # 1, 2, 3, or 4vim sc
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step test --kge ${kge} --gpu cuda:${gpu} --emb_dim ${dim} --num_train_subgraph ${num_train_subgraph}

version=2 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step test --kge ${kge} --gpu cuda:${gpu} --emb_dim ${dim} --num_train_subgraph ${num_train_subgraph}

version=3 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step test --kge ${kge} --gpu cuda:${gpu} --emb_dim ${dim} --num_train_subgraph ${num_train_subgraph}

version=4 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step test --kge ${kge} --gpu cuda:${gpu} --emb_dim ${dim} --num_train_subgraph ${num_train_subgraph}



dataset='fb237' # 'fb237', 'WN18RR', or 'nell'
version=1 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step test --kge ${kge} --gpu cuda:${gpu} --emb_dim ${dim} --num_train_subgraph ${num_train_subgraph}

version=2 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step test --kge ${kge} --gpu cuda:${gpu} --emb_dim ${dim} --num_train_subgraph ${num_train_subgraph}

version=3 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step test --kge ${kge} --gpu cuda:${gpu} --emb_dim ${dim} --num_train_subgraph ${num_train_subgraph}

version=4 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step test --kge ${kge} --gpu cuda:${gpu} --emb_dim ${dim} --num_train_subgraph ${num_train_subgraph}

