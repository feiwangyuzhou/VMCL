#!/bin/sh

kge='ComplEx' # 'TransE', 'DistMult', 'ComplEx', or 'RotatE'
gpu=0

#dataset='fb237' # 'fb237', 'WN18RR', or 'nell'
#version=1 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=2 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu} --metatrain_bs 64
#
#version=2 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=2 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu} --metatrain_bs 64
#
#version=3 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=2 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu} --metatrain_bs 32
#
#version=4 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=2 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu} --metatrain_bs 32


dataset='nell' # 'fb237', 'WN18RR', or 'nell'
#version=1 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=2 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu} --metatrain_bs 64

version=2 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step meta_train --kge ${kge} --gpu cuda:${gpu} --metatrain_bs 32

#version=3 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=2 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu} --metatrain_bs 32
#
#version=4 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=2 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu} --metatrain_bs 32