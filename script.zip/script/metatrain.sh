#!/bin/sh

dataset='nell' # 'fb237', 'WN18RR', or 'nell'
kge='TransE' # 'TransE', 'DistMult', 'ComplEx', or 'RotatE'
gpu=0

version=1 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=3 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
        --step meta_train --kge ${kge} --gpu cuda:${gpu}

#version=2 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=5 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu}
#
#version=3 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=5 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu}
#
#version=4 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=5 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,} \
#        --step meta_train --kge ${kge} --gpu cuda:${gpu}