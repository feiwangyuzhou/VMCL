#!/bin/sh

gpu=0
kge='RotatE' # 'TransE', 'DistMult', 'ComplEx', or 'RotatE'


dataset='fb237' # 'fb237', 'WN18RR', or 'nell'
#version=1 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=3 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
#        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
#        --step fine_tune --kge ${kge} --gpu cuda:${gpu}

#version=2 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=2 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
#        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
#        --step fine_tune --kge ${kge} --gpu cuda:${gpu}

version=3 # 1, 2, 3, or 4
CUDA_VISIBLE_DEVICES=3 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
        --step fine_tune --kge ${kge} --gpu cuda:${gpu}
CUDA_VISIBLE_DEVICES=3 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
        --step fine_tune --kge ${kge} --gpu cuda:${gpu}
CUDA_VISIBLE_DEVICES=3 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
        --step fine_tune --kge ${kge} --gpu cuda:${gpu}
CUDA_VISIBLE_DEVICES=3 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
        --step fine_tune --kge ${kge} --gpu cuda:${gpu}
CUDA_VISIBLE_DEVICES=3 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
        --step fine_tune --kge ${kge} --gpu cuda:${gpu}






#version=4 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
#        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
#        --step fine_tune --kge ${kge} --gpu cuda:${gpu}
#
#
#dataset='nell' # 'fb237', 'WN18RR', or 'nell'
#version=1 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
#        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
#        --step fine_tune --kge ${kge} --gpu cuda:${gpu}
#
#version=2 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
#        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
#        --step fine_tune --kge ${kge} --gpu cuda:${gpu}
#
#version=3 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
#        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
#        --step fine_tune --kge ${kge} --gpu cuda:${gpu}
#
#version=4 # 1, 2, 3, or 4
#CUDA_VISIBLE_DEVICES=1 python main.py --data_name ${dataset}_v${version} --name ${dataset,,}_v${version}_${kge,,}_finetune \
#        --metatrain_state ./state/${dataset,,}_v${version}_${kge,,}/${dataset,,}_v${version}_${kge,,}.best \
#        --step fine_tune --kge ${kge} --gpu cuda:${gpu}